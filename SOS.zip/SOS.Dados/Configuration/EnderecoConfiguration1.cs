﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SOS.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOS.Dados.Configuration
{
    public class EnderecoConfiguration : IEntityTypeConfiguration<Endereco>

    {
        public void Configure(EntityTypeBuilder<Endereco> builder)
        {
            builder.ToTable("Endereco");
            builder.HasKey(f => f.EnderecoID);

            builder
                .Property(f => f.CEP)
                .UseIdentityColumn()
                .HasColumnName("CEP")
                .HasColumnType("varchar(10)");

            builder
             .Property(f => f.Cidade)
             .UseIdentityColumn()
             .HasColumnName("Cidade")
             .HasColumnType("varchar(50)");

            builder
             .Property(f => f.Estado)
             .UseIdentityColumn()
             .HasColumnName("Estado")
             .HasColumnType("varchar(50)");


            builder
             .Property(f => f.Logradouro)
             .UseIdentityColumn()
             .HasColumnName("Logradouro")
             .HasColumnType("varchar(100)");


            builder
             .Property(f => f.Bairro)
             .UseIdentityColumn()
             .HasColumnName("Bairro")
             .HasColumnType("varchar(50)");


            builder
             .Property(f => f.Numero)
             .UseIdentityColumn()
             .HasColumnName("Numero")
             .HasColumnType("int");
        }
    }
}