﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOS.Dominio.Entidades
{
    public class Tutor : Pessoa
    {
        public int TutorID { get; set; }

    }
}
