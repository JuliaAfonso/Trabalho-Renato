﻿using Microsoft.AspNetCore.Mvc;

namespace SOS.WEBAPP.Controllers
{
    public class EspecieController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
